clear all
clc
close all



data_analysis
output
moments
plotspaper
tablespaper