
num=corrcoef(simY,simCAY);
rhoycay=num(2,1);
num=corrcoef(simY,simTBY);
rhoytby=num(2,1);

num=corrcoef(simYp,simCAYp);
rhoycayp=num(2,1);
num=corrcoef(simYp,simTBYp);
rhoytbyp=num(2,1);

num=corrcoef(simY,simC);
rhoyc=num(2,1);


num=corrcoef(simYp,simCp);
rhoycp=num(2,1);


num=corrcoef(simY,simRER);
rhoyrer=num(2,1);
num=corrcoef(simYp,simRERp);
rhoyrerp=num(2,1);



